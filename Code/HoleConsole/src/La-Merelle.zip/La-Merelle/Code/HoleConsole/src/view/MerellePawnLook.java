package view;

import boardifier.model.GameElement;
import boardifier.view.ConsoleColor;
import boardifier.view.ElementLook;
import model.MerellePawn;

/**
 * Look console d'un pion de la Mérelle.
 *
 * Chaque pion est représenté par un unique caractère coloré en console.
 * La chaîne placée dans shape[0][0] combine :
 *   1. la couleur du texte   (blanc ou noir selon le contraste avec le fond)
 *   2. la couleur du fond    (couleur choisie par le joueur)
 *   3. la lettre du pion     (N, R, B, V, J, M ou C)
 *   4. le code ANSI de reset (ConsoleColor.RESET) pour ne pas déborder
 *
 * Correspondance couleur → affichage :
 *   PAWN_BLACK  (0) → fond noir,   lettre 'N' blanche
 *   PAWN_RED    (1) → fond rouge,  lettre 'R' noire
 *   PAWN_BLUE   (2) → fond bleu,   lettre 'B' blanche
 *   PAWN_GREEN  (3) → fond vert,   lettre 'V' noire
 *   PAWN_YELLOW (4) → fond jaune,  lettre 'J' noire
 *   PAWN_PURPLE (5) → fond violet, lettre 'M' blanche
 *   PAWN_CYAN   (6) → fond cyan,   lettre 'C' noire
 *
 * La taille du look est fixée à 1×1 : un seul caractère affiché,
 * même si la chaîne stockée contient des codes ANSI invisibles.
 * ClassicBoardLook centre ce caractère dans sa cellule grâce aux
 * alignements ALIGN_MIDDLE / ALIGN_CENTER définis dans ClassicBoardLook.
 *
 * Calqué sur PawnLook.java du tutoriel HoleConsole.
 */
public class MerellePawnLook extends ElementLook {

    /**
     * Crée le look d'un pion.
     *
     * La taille 1×1 correspond à un seul caractère affiché en console.
     * Le depth par défaut (0) place ce look au-dessus du plateau (depth=1...
     * non, ClassicBoardLook a depth=1 et les pions sont dans les cellules
     * via addInnerLook géré automatiquement par boardifier).
     *
     * @param element le MerellePawn associé à ce look
     */
    public MerellePawnLook(GameElement element) {

        super(element, 1, 1);
    }

    /**
     * Construit la représentation visuelle du pion dans shape[0][0].
     *
     * Les méthodes getTextColor(), getBackgroundColor() et getSymbol()
     * sont définies dans MerellePawn et retournent les codes ANSI et la
     * lettre correspondant à la couleur choisie par le joueur.
     */
    @Override
    protected void render() {

        MerellePawn pawn = (MerellePawn) element;

        shape[0][0] = pawn.getTextColor()
                + pawn.getBackgroundColor()
                + pawn.getSymbol()
                + ConsoleColor.RESET;
    }
}