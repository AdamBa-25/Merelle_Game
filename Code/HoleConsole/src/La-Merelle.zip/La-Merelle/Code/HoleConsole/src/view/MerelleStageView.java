package view;

import boardifier.model.GameException;
import boardifier.model.GameStageModel;
import boardifier.view.ClassicBoardLook;
import boardifier.view.GameStageView;
import boardifier.view.TextLook;
import model.MerelleStageModel;

/**
 * Vue console du jeu de la Mérelle.
 *
 * Cette classe est le point d'entrée de la couche View dans le paradigme MVC
 * utilisé par boardifier. Elle crée l'ensemble des "looks" (représentations
 * visuelles) de tous les éléments du stage et les enregistre dans la liste
 * interne de GameStageView, qui sera parcourue par RootPane lors du rendu.
 *
 * Éléments rendus (dans l'ordre d'ajout = ordre de rendu, du fond vers le premier plan) :
 *   1. TextLook        → affiche le nom du joueur courant au-dessus du plateau.
 *   2. ClassicBoardLook → dessine la grille 7×7 du plateau avec ses coordonnées
 *                          (colonnes A-G, lignes 1-7) et ses bordures double-trait.
 *   3. MerellePawnLook  → un look par pion (joueur 1 et joueur 2), superposé
 *                          sur la cellule correspondante du plateau.
 *
 * Paramètres de ClassicBoardLook :
 *   - rowHeight = 2  : chaque ligne de la grille occupe 2 caractères en hauteur,
 *                      ce qui donne de l'espace visuel entre les rangées.
 *   - colWidth  = 4  : chaque colonne occupe 4 caractères, ce qui centre
 *                      bien la lettre du pion et les coordonnées A-G.
 *   - depth     = 1  : rendu au-dessus du fond (valeur standard).
 *   - borderWidth = 1 : affiche les bordures double-trait entre les cellules.
 *   - showCoords = true : affiche les labels de colonnes (A-G) et de lignes (1-7).
 *
 * Le rendu console obtenu est une grille 7×7 complète, les 24 positions valides
 * de la Mérelle correspondant aux cellules utilisées par le modèle (voir
 * MerelleBoard.POS_TO_GRID). Les 25 cellules restantes apparaissent vides.
 *
 * Calqué sur HoleStageView.java du tutoriel HoleConsole.
 */
public class MerelleStageView extends GameStageView {

    /**
     * Construit la vue du stage de la Mérelle.
     *
     * @param name           nom du stage (doit correspondre à celui enregistré
     *                       dans StageFactory via StageFactory.registerView())
     * @param gameStageModel modèle du stage fourni par boardifier
     */
    public MerelleStageView(String name, GameStageModel gameStageModel) {

        super(name, gameStageModel);
    }

    /**
     * Crée et enregistre tous les looks du stage.
     *
     * Appelée automatiquement par boardifier lors de l'initialisation du stage.
     * Chaque appel à addLook() enregistre le look dans la liste de GameStageView
     * et déclenche un premier render() immédiat.
     *
     * @throws GameException si le modèle est dans un état invalide
     */
    @Override
    public void createLooks() throws GameException {

        MerelleStageModel model = (MerelleStageModel) gameStageModel;

        // --- 1. Texte : nom du joueur courant ---
        // TextLook lit automatiquement le contenu du TextElement à chaque render().
        addLook(new TextLook(model.getPlayerName()));

        // --- 2. Plateau : grille 7×7 avec coordonnées et bordures ---
        // rowHeight=2 et colWidth=4 donnent des cellules assez grandes pour
        // afficher lisiblement la lettre du pion (N, R, B...) et les labels.
        // depth=1 place le plateau sur la couche standard (au-dessus du fond).
        // borderWidth=1 active les bordures double-trait Unicode (╔ ═ ╗ ║ ╬ ╝...).
        // showCoords=true ajoute la rangée de lettres A-G en haut et la colonne
        // de chiffres 1-7 à gauche, conformément au système de coordonnées du modèle.
        addLook(new ClassicBoardLook(2, 4, model.getBoard(), 1, 1, true));

        // --- 3. Pions joueur 1 ---
        for (MerellePawnLook look : createPawnLooks(model.getPawnsJ1())) {
            addLook(look);
        }

        // --- 4. Pions joueur 2 ---
        for (MerellePawnLook look : createPawnLooks(model.getPawnsJ2())) {
            addLook(look);
        }
    }

    // =========================================================================
    //  Méthode auxiliaire
    // =========================================================================

    /**
     * Crée un MerellePawnLook pour chaque pion du tableau donné.
     *
     * Cette méthode factorise la création des looks pour éviter la duplication
     * entre les pions du joueur 1 et ceux du joueur 2.
     *
     * @param pawns tableau de pions (joueur 1 ou joueur 2), de taille 9
     * @return tableau de MerellePawnLook correspondants, dans le même ordre
     */
    private MerellePawnLook[] createPawnLooks(model.MerellePawn[] pawns) {

        MerellePawnLook[] looks = new MerellePawnLook[pawns.length];

        for (int i = 0; i < pawns.length; i++) {
            looks[i] = new MerellePawnLook(pawns[i]);
        }

        return looks;
    }
}